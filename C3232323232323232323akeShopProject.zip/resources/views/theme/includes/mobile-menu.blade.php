<!-- Mobile menu start -->
<div class="mobile-menu-active clickalbe-sidebar-wrapper-style-1">
    <div class="clickalbe-sidebar-wrap">
        <a class="sidebar-close"><i class="icofont-close-line"></i></a>
        <div class="mobile-menu-content-area sidebar-content-100-percent">
            <div class="mobile-search">
                <form class="search-form" action="#">
                    <input type="text" placeholder="Search here…">
                    <button class="button-search"><i class="icofont-search-1"></i></button>
                </form>
            </div>
            <div class="clickable-mainmenu-wrap clickable-mainmenu-style1">
                <nav>
                    <ul>
                        <li class="has-sub-menu"><a href="index.html">Home</a>
                        </li>
                        <li class="has-sub-menu"><a href="#shopess">shop</a>

                        </li>

                        <li><a href="FAQ.html">FAQ</a></li>
                        <li><a href="contact-us.html">Contact</a></li>
                    </ul>
                </nav>
            </div>
            <div class="mobile-curr-lang-wrap">
                <div class="single-mobile-curr-lang">
                    <a class="mobile-language-active" href="#">Language <i class="icofont-simple-down"></i></a>
                    <div class="lang-curr-dropdown lang-dropdown-active">
                        <ul>
                            <li><a href="#">English</a></li>
                            <li><a href="#">Spanish</a></li>
                            <li><a href="#">Hindi </a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="aside-contact-info">
                <ul>
                    <li><i class="icofont-clock-time"></i>Monday - Friday: 9:00 - 19:00</li>
                    <li><i class="icofont-envelope"></i>Info@example.com</li>
                    <li><i class="icofont-stock-mobile"></i>(+55) 254. 254. 254</li>
                    <li><i class="icofont-home"></i>Helios Tower 75 Tam Trinh Hoang - Ha Noi - Viet Nam</li>
                </ul>
            </div>
        </div>
    </div>
</div>
